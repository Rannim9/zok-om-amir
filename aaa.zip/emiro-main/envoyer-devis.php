<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/PHPMailer/src/Exception.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "Erreur : formulaire non soumis.";
    exit;
}

// Récupération des champs
$prenom     = $_POST['prenom'] ?? '';
$nom        = $_POST['nom'] ?? '';
$email      = $_POST['email'] ?? '';
$telephone  = $_POST['telephone'] ?? '';
$logement   = $_POST['logement'] ?? '';
$etatProjet = $_POST['etatProjet'] ?? '';
$surface    = $_POST['surface'] ?? '';
$chauffage  = $_POST['chauffage'] ?? '';
$annee      = $_POST['annee'] ?? '';
$dpe        = $_POST['dpe'] ?? '';
$travaux    = $_POST['travaux'] ?? [];
$adresse1   = $_POST['adresse1'] ?? '';
$adresse2   = $_POST['adresse2'] ?? '';
$ville      = $_POST['ville'] ?? '';
$region     = $_POST['region'] ?? '';
$codePostal = $_POST['codePostal'] ?? '';

// Vérification des champs obligatoires
if (empty($prenom) || empty($email) || empty($nom) || empty($telephone)) {
    echo "Erreur : veuillez remplir tous les champs obligatoires.";
    exit;
}

$mail = new PHPMailer(true);

try {
    $mail->CharSet = 'UTF-8';
    $mail->SMTPDebug = 0;  
    $mail->isSMTP();
    $mail->Host       = 'ssl0.ovh.net';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'contact@evropen.fr';
    $mail->Password   = 'Acier045.1986';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    $mail->SMTPOptions = [
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        ]
    ];

    $mail->setFrom('contact@evropen.fr', 'Evropen');
    $mail->addAddress('contact@evropen.fr', 'Evropen'); 

    $mail->isHTML(true);
    $mail->Subject = 'Nouvelle demande de devis';

    // Construction du message
    $body = "<h3>Nouvelle demande de devis :</h3>";
    $body .= "<b>Prénom :</b> $prenom<br>";
    $body .= "<b>Nom :</b> $nom<br>";
    $body .= "<b>Email :</b> $email<br>";
    $body .= "<b>Téléphone :</b> $telephone<br>";
    $body .= "<b>Type de logement :</b> $logement<br>";
    $body .= "<b>État du projet :</b> $etatProjet<br>";
    $body .= "<b>Surface :</b> $surface<br>";
    $body .= "<b>Mode de chauffage :</b> $chauffage<br>";
    $body .= "<b>Année de construction :</b> $annee<br>";
    $body .= "<b>Classe énergétique :</b> $dpe<br>";
    if (!empty($travaux)) {
        $body .= "<b>Travaux envisagés :</b> " . implode(", ", $travaux) . "<br>";
    }
    $body .= "<b>Adresse :</b> $adresse1";
    if (!empty($adresse2)) $body .= ", $adresse2";
    $body .= ", $ville, $region, $codePostal<br>";

    $mail->Body = $body;

    $mail->send();
    echo "Merci $prenom ! Votre demande de devis a bien été reçue. Nous vous contacterons très bientôt.";

} catch (Exception $e) {
    echo "Erreur PHPMailer : {$mail->ErrorInfo}";
}
