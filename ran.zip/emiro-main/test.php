<?php
echo "PHP fonctionne !";
?>