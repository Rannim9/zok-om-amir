<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = $_POST['name'];
    $email   = $_POST['email'];
    $message = $_POST['message'];

    $mail = new PHPMailer(true);

    try {
        // Paramètres serveur
        $mail->isSMTP();
        $mail->Host       = 'ssl0.ovh.net';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'contact@evropen.fr';
        $mail->Password   = 'Acier045.1986'; // 🔒
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;   

        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer'  => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );

        $mail->setFrom('contact@evropen.fr', 'Evropen');
        $mail->addAddress('contact@evropen.fr');

        $mail->isHTML(true);
        $mail->Subject = "Nouvelle demande de devis - $name";
        $mail->Body    = "
            <h2>Demande de devis</h2>
            <p><b>Nom :</b> $name</p>
            <p><b>Email :</b> $email</p>
            <p><b>Message :</b><br>$message</p>
        ";

        $mail->send();
        echo "Merci $name ! Votre demande de devis a bien été reçue. Nous vous contacterons très bientôt.";
    } catch (Exception $e) {
        echo "Erreur lors de l'envoi : {$mail->ErrorInfo}";
    }
}
?>
